package com.spring.soap.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.soap.test.client.SoapClient;
import com.spring.soap.test.config.SoapClientConfig;

@SpringBootApplication
public class ConsumingSoapWebServiceApplication {

    public static void main(String[] args) {

        SpringApplication.run(ConsumingSoapWebServiceApplication.class, args);
        AnnotationConfigApplicationContext annotationConfigApplicationContext = new AnnotationConfigApplicationContext(SoapClientConfig.class);
        SoapClient soapClient = annotationConfigApplicationContext.getBean(SoapClient.class);
        System.out.println(soapClient.getArticle(2).getArticle().getName());
    }

}
